
package View;

import javax.swing.JOptionPane;


public class Menu_Cotizacion extends javax.swing.JFrame {

    public Menu_Cotizacion() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtMenuInvitados = new javax.swing.JLabel();
        btgProveedores = new javax.swing.JButton();
        btVolver = new javax.swing.JButton();
        background2 = new javax.swing.JPanel();
        Icon = new javax.swing.JLabel();
        txtIcon = new javax.swing.JLabel();
        btgUsuario = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Menú de Cotización");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        txtMenuInvitados.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        txtMenuInvitados.setText("OPCIONES DE COTIZACIÓN");

        btgProveedores.setBackground(new java.awt.Color(51, 204, 255));
        btgProveedores.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N
        btgProveedores.setForeground(new java.awt.Color(255, 255, 255));
        btgProveedores.setText("COTIZAR OFERTA EN EXISTENCIA");
        btgProveedores.setBorder(null);
        btgProveedores.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btgProveedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btgProveedoresActionPerformed(evt);
            }
        });

        btVolver.setBackground(new java.awt.Color(51, 204, 255));
        btVolver.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N
        btVolver.setForeground(new java.awt.Color(255, 255, 255));
        btVolver.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/vuelve.PNG"))); // NOI18N
        btVolver.setText("VOLVER");
        btVolver.setBorder(null);
        btVolver.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btVolverActionPerformed(evt);
            }
        });

        background2.setBackground(new java.awt.Color(51, 204, 255));
        background2.setForeground(new java.awt.Color(255, 255, 255));
        background2.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N

        Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/istockphoto-1293734400-612x612.jpg"))); // NOI18N
        Icon.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                IconMouseClicked(evt);
            }
        });

        txtIcon.setFont(new java.awt.Font("Microsoft YaHei", 1, 24)); // NOI18N
        txtIcon.setForeground(new java.awt.Color(255, 255, 255));
        txtIcon.setText("FERRETERÍA COINCO");

        javax.swing.GroupLayout background2Layout = new javax.swing.GroupLayout(background2);
        background2.setLayout(background2Layout);
        background2Layout.setHorizontalGroup(
            background2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(background2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(Icon)
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, background2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 288, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
        background2Layout.setVerticalGroup(
            background2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(background2Layout.createSequentialGroup()
                .addGap(99, 99, 99)
                .addComponent(Icon, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtIcon, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btgUsuario.setBackground(new java.awt.Color(51, 204, 255));
        btgUsuario.setFont(new java.awt.Font("Microsoft YaHei", 1, 14)); // NOI18N
        btgUsuario.setForeground(new java.awt.Color(255, 255, 255));
        btgUsuario.setText("COTIZAR PRODUCTO");
        btgUsuario.setBorder(null);
        btgUsuario.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btgUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btgUsuarioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(77, 77, 77)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btgUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btgProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 134, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtMenuInvitados)
                        .addGap(154, 154, 154)))
                .addComponent(background2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(background2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(txtMenuInvitados)
                .addGap(81, 81, 81)
                .addComponent(btgUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(btgProveedores, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 285, Short.MAX_VALUE)
                .addComponent(btVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btgProveedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btgProveedoresActionPerformed
        int a=0;
        try{
        a=Integer.parseInt(JOptionPane.showInputDialog(rootPane, "Introduzca el número de la oferta que desea comprar.", "Compra de oferta", a));
        if (a>=0 && a<=4){
            JOptionPane.showInputDialog(rootPane, "Introduzca el código de su tarjeta de crédito.", "Transferencia", WIDTH);
            JOptionPane.showMessageDialog(rootPane, "La oferta ha sido comprada con éxito.");            
        }
        else {
            JOptionPane.showMessageDialog(rootPane, "La oferta seleccionada no está en existencia.");
        }    
        }
        catch (NumberFormatException ex){
            
        }        
    }//GEN-LAST:event_btgProveedoresActionPerformed

    private void btVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btVolverActionPerformed
        Menu_Cliente ventana = new Menu_Cliente();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);

        this.dispose();
    }//GEN-LAST:event_btVolverActionPerformed

    private void IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IconMouseClicked

    }//GEN-LAST:event_IconMouseClicked

    private void btgUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btgUsuarioActionPerformed
        int a=0;
        try{
            a=Integer.parseInt(JOptionPane.showInputDialog(rootPane, "Introduzca el número del producto que desea comprar.", "Compra de producto", a));
        if (a>=0 && a<=10){
            JOptionPane.showInputDialog(rootPane, "Introduzca el código de su tarjeta de crédito.", "Transferencia", WIDTH);
            JOptionPane.showMessageDialog(rootPane, "El producto ha sido comprado con éxito.");            
        }
        else {
            JOptionPane.showMessageDialog(rootPane, "El producto seleccionado no se encuentra en el almacen.");
        } 
        }
        catch (NumberFormatException ex){
            
        }       
    }//GEN-LAST:event_btgUsuarioActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Icon;
    private javax.swing.JPanel background2;
    private javax.swing.JButton btVolver;
    private javax.swing.JButton btgProveedores;
    private javax.swing.JButton btgUsuario;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel txtIcon;
    private javax.swing.JLabel txtMenuInvitados;
    // End of variables declaration//GEN-END:variables
}
