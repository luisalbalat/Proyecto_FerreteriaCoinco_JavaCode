package Model;

    public class CuadernoAnotaciones {
    
        private String ventas;
        private double montoTotal;

    public String getVentas() {
        return ventas;
    }

    public void setVentas(String ventas) {
        this.ventas = ventas;
    }

    public double getMontoTotal() {
        return montoTotal;
    }

    public void setMontoTotal(double montoTotal) {
        this.montoTotal = montoTotal;
    }

    public CuadernoAnotaciones(String ventas, double montoTotal) {
        this.ventas = ventas;
        this.montoTotal = montoTotal;
    }
        
    
}
