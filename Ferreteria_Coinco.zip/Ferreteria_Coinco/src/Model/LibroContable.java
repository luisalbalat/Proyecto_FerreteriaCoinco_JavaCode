package Model;

    public class LibroContable {
    
        private String comprasProveedor;
        private String ventasEmpresa;

    public String getComprasProveedor() {
        return comprasProveedor;
    }

    public void setComprasProveedor(String comprasProveedor) {
        this.comprasProveedor = comprasProveedor;
    }

    public String getVentasEmpresa() {
        return ventasEmpresa;
    }

    public void setVentasEmpresa(String ventasEmpresa) {
        this.ventasEmpresa = ventasEmpresa;
    }

    public LibroContable(String comprasProveedor, String ventasEmpresa) {
        this.comprasProveedor = comprasProveedor;
        this.ventasEmpresa = ventasEmpresa;
    }
        
    
}
