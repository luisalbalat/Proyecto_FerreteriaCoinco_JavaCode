package Controller;

import View.Login;

    public class Proyecto_DPOO {

        public static void main(String[] args) {
        
            Login ventana = new Login();
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
            
        }
    
}
